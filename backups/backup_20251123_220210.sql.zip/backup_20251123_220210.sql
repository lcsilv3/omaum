﻿--
-- PostgreSQL database dump
--

\restrict e5imXzLwLa16PR59jJAPCQ8nPA7avV21L4niJiT4cf0iZQI45BXPMUqCHGNTC5W

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: omaum_app
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO omaum_app;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: omaum_app
--

COMMENT ON SCHEMA public IS '';


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: omaum_app
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict e5imXzLwLa16PR59jJAPCQ8nPA7avV21L4niJiT4cf0iZQI45BXPMUqCHGNTC5W

